export { defaultNotes } from "./notesData";
