import { useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { WIDGET_OPTIONS } from "@store/widgets";
import useTimeStore from "@store/time";
import WEATHER_DATA from "@module/desktop/apps/weather/data/weatherData";
import AnalogClockFace from "@module/desktop/widgets/ui/components/AnalogClockFace";

const WidgetPreview = ({ type }) => {
  const time = useTimeStore((state) => state.time);
  const timeLabel = `${String(time.getHours()).padStart(2, "0")}:${String(time.getMinutes()).padStart(2, "0")}`;
  const day = time.getDate();
  const monthStart = new Date(time.getFullYear(), time.getMonth(), 1).getDay();
  const monthLength = new Date(time.getFullYear(), time.getMonth() + 1, 0).getDate();
  const monthDays = [
    ...Array(monthStart).fill(null),
    ...Array.from({ length: monthLength }, (_, index) => index + 1),
  ];

  if (type === "battery") {
    return (
      <div className="flex h-full w-full items-center gap-2.5 bg-black/20 px-3 text-white">
        <div className="relative h-6 w-11 rounded-[5px] border border-white/70 p-[2px]">
          <span className="block h-full w-3/4 rounded-[2px] bg-green-400" />
          <span className="absolute -right-1 top-1.5 h-2 w-1 rounded-r-sm bg-white/70" />
        </div>
        <div>
          <span className="block text-[11px] font-medium">Battery</span>
          <span className="text-[9px] text-white/60">Power status</span>
        </div>
      </div>
    );
  }

  if (type === "notes") {
    return (
      <div className="flex h-full w-full flex-col justify-center bg-gradient-to-br from-amber-100 to-yellow-200 px-3 text-zinc-700">
        <span className="text-[10px] font-semibold">Quick Note</span>
        <span className="mt-1 text-[8px] leading-tight text-zinc-500">
          Ideas, reminders, and things to remember.
        </span>
      </div>
    );
  }

  if (type === "weather") {
    return (
      <>
        <img
          src="/weather/sunny-sky.webp"
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
        <span className="absolute inset-0 bg-gradient-to-b from-sky-950/20 via-transparent to-sky-950/70" />
        <span className="absolute left-3 top-2 text-[9px] font-medium text-white/90">Delhi</span>
        <span className="absolute bottom-2 left-3 text-3xl font-light text-white">
          {WEATHER_DATA.delhi.tempC}°
        </span>
        <span className="absolute bottom-3 right-3 text-[9px] text-white/90">
          {WEATHER_DATA.delhi.condition}
        </span>
      </>
    );
  }

  if (type === "clock") {
    return (
      <div className="flex h-full w-full flex-col items-center justify-center bg-black/20 text-white">
        <span className="text-[32px] font-light tracking-tight">{timeLabel}</span>
        <span className="text-[9px] text-white/70">
          {time.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
        </span>
      </div>
    );
  }

  if (type === "analog-clock") {
    return (
      <div className="flex h-full w-full items-center justify-center bg-black/20">
        <AnalogClockFace time={time} className="h-[52px] w-[52px] drop-shadow-md" />
      </div>
    );
  }

  return (
    <div className="flex h-full w-full items-center gap-2 bg-black/20 px-2.5 text-white">
      <div className="min-w-0 flex-1">
        <span className="block truncate text-[7px] font-medium text-white/70">
          {time.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
        </span>
        <span className="mt-0.5 block text-[19px] font-light tracking-tight">{timeLabel}</span>
      </div>
      <div className="grid w-[54px] shrink-0 grid-cols-7 gap-x-0.5 gap-y-0.5 text-center text-[6px] text-white/65">
        {["S", "M", "T", "W", "T", "F", "S", ...monthDays.slice(0, 14)].map((date, index) => (
          <span key={index} className={date === day ? "rounded-full bg-blue-500 text-white" : ""}>
            {date}
          </span>
        ))}
      </div>
    </div>
  );
};

const DesktopContextMenu = ({
  menu,
  onClose,
  onNewFolder,
  onGetInfo,
  activeWidgets = [],
  onToggleWidget,
  onOpenProjects,
  onOpenProject,
  projects = [],
  onOpenApp,
  onOpenTerminal,
  onOpenSettings,
  onCleanUp,
  onOpenFolder,
  onRenameFolder,
  onDeleteFolder,
  onDeleteCustomFolder,
  onOpenShortcut,
  onDeleteShortcut,
}) => {
  const menuRef = useRef(null);
  const [activeSubmenu, setActiveSubmenu] = useState(null);
  const [copied, setCopied] = useState(false);

  // Close when clicking outside or pressing Escape / shortcut key
  useEffect(() => {
    const handlePointerDown = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        onClose();
      }
    };

    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        onClose();
      } else if (
        (e.key === "Backspace" || e.key === "Delete") &&
        (e.metaKey || e.ctrlKey || menu?.type === "folder" || menu?.type === "shortcut")
      ) {
        if (menu?.type === "folder" && menu?.target) {
          e.preventDefault();
          if (onDeleteFolder) {
            onDeleteFolder(menu.target);
          } else if (onDeleteCustomFolder) {
            onDeleteCustomFolder(menu.target?.id);
          }
          onClose();
        } else if (menu?.type === "shortcut" && menu?.target) {
          e.preventDefault();
          if (onDeleteShortcut) {
            onDeleteShortcut(menu.target.id);
          }
          onClose();
        }
      }
    };

    window.addEventListener("pointerdown", handlePointerDown);
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("resize", onClose);

    return () => {
      window.removeEventListener("pointerdown", handlePointerDown);
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("resize", onClose);
    };
  }, [menu, onDeleteFolder, onDeleteCustomFolder, onDeleteShortcut, onClose]);

  if (!menu) return null;

  // Keep the menu and its side panels clear of the dock.
  const menuWidth = 240;
  const menuHeight = menu.type === "desktop" ? 300 : 180;
  const dockTop = document.querySelector("#dock:not(.dock-hidden)")?.getBoundingClientRect().top;
  const menuBottom = Math.min(window.innerHeight - 10, (dockTop ?? window.innerHeight) - 8);
  const left = Math.max(10, Math.min(menu.x, window.innerWidth - menuWidth - 10));
  const top = Math.max(8, Math.min(menu.y, menuBottom - menuHeight));
  const openSubmenuLeft = left + menuWidth + 4 + 180 > window.innerWidth - 8;
  const sidePanelHeight = 310;
  const widgetSubmenuWidth = 264;
  const openWidgetSubmenuLeft = left + menuWidth + widgetSubmenuWidth > window.innerWidth - 8;
  const widgetSubmenuLeft = Math.max(
    8,
    Math.min(
      openWidgetSubmenuLeft ? left - widgetSubmenuWidth : left + menuWidth,
      window.innerWidth - widgetSubmenuWidth - 8,
    ),
  );
  const widgetSubmenuOffsetLeft = widgetSubmenuLeft - left - 4;
  const widgetSubmenuTop = Math.max(8, Math.min(top + 86, menuBottom - sidePanelHeight));
  const widgetSubmenuOffsetTop = widgetSubmenuTop - top - 86;

  const handleCopy = (text) => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => {
        setCopied(false);
        onClose();
      }, 600);
    } else {
      onClose();
    }
  };

  return createPortal(
    <div
      ref={menuRef}
      className="fixed z-[99999] w-[240px] select-none rounded-[10px] p-1 font-sans text-[13px] leading-tight text-[#f5f5f7] animate-in fade-in zoom-in-95 duration-100 ease-out shadow-[0_18px_40px_rgba(0,0,0,0.55),0_0_0_1px_rgba(255,255,255,0.12)_inset]"
      style={{
        left: `${left}px`,
        top: `${top}px`,
        background:
          "linear-gradient(135deg, rgba(44, 44, 48, 0.62), rgba(26, 26, 30, 0.5) 45%, rgba(38, 38, 44, 0.58))",
        backdropFilter: "blur(36px) saturate(190%)",
        WebkitBackdropFilter: "blur(36px) saturate(190%)",
        border: "1px solid rgba(255, 255, 255, 0.2)",
        boxShadow:
          "inset 0 1px 0 rgba(255, 255, 255, 0.3), inset 0 -1px 0 rgba(255, 255, 255, 0.07), 0 18px 48px rgba(0, 0, 0, 0.5), 0 4px 14px rgba(0, 0, 0, 0.28)",
      }}
      onClick={(e) => e.stopPropagation()}
      onContextMenu={(e) => {
        e.preventDefault();
        e.stopPropagation();
      }}
    >
      {/* ─── DESKTOP CONTEXT MENU ─── */}
      {menu.type === "desktop" && (
        <div className="flex flex-col">
          {/* New Folder */}
          <button
            onClick={() => {
              onNewFolder();
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>New Folder</span>
            <span className="text-[12px] text-white/40 tracking-wider group-hover:text-white">
              ⇧⌘N
            </span>
          </button>

          <div className="my-1 h-[0.5px] bg-white/12 mx-1" />

          {/* Get Info */}
          <button
            onClick={() => {
              onGetInfo();
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Get Info</span>
            <span className="text-[12px] text-white/40 tracking-wider group-hover:text-white">
              ⌘I
            </span>
          </button>

          {/* Add Widgets */}
          <div
            className="relative"
            onMouseEnter={() => setActiveSubmenu("widgets")}
            onMouseLeave={() => setActiveSubmenu(null)}
          >
            {activeSubmenu === "widgets" && (
              <span
                aria-hidden="true"
                className={`pointer-events-auto absolute top-0 z-[99999] h-full w-1 ${
                  openWidgetSubmenuLeft ? "right-full" : "left-full"
                }`}
              />
            )}
            <button
              onClick={() =>
                setActiveSubmenu((current) => (current === "widgets" ? null : "widgets"))
              }
              aria-haspopup="true"
              aria-expanded={activeSubmenu === "widgets"}
              className={`group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors cursor-default ${
                activeSubmenu === "widgets"
                  ? "bg-gradient-to-b from-[#1687ff] to-[#0071e3] text-white"
                  : "hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white"
              }`}
            >
              <span>Add Widgets</span>
              <svg
                className="h-3 w-3 text-white/50 group-hover:text-white"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
              >
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </button>

            {activeSubmenu === "widgets" && (
              <div
                className="absolute z-[100000] w-[264px] max-w-[calc(100vw-16px)] rounded-[10px] p-2 font-sans text-[13px] text-[#f5f5f7] shadow-[0_18px_40px_rgba(0,0,0,0.55),0_0_0_1px_rgba(255,255,255,0.12)_inset] animate-in fade-in zoom-in-95 duration-100"
                style={{
                  left: `${widgetSubmenuOffsetLeft}px`,
                  top: `${widgetSubmenuOffsetTop}px`,
                  maxHeight: `${Math.max(0, menuBottom - widgetSubmenuTop)}px`,
                  overflowY: "auto",
                  background:
                    "linear-gradient(135deg, rgba(44, 44, 48, 0.66), rgba(26, 26, 30, 0.54) 45%, rgba(38, 38, 44, 0.62))",
                  backdropFilter: "blur(36px) saturate(190%)",
                  WebkitBackdropFilter: "blur(36px) saturate(190%)",
                  border: "1px solid rgba(255, 255, 255, 0.2)",
                  boxShadow:
                    "inset 0 1px 0 rgba(255, 255, 255, 0.3), inset 0 -1px 0 rgba(255, 255, 255, 0.07), 0 18px 48px rgba(0, 0, 0, 0.5), 0 4px 14px rgba(0, 0, 0, 0.28)",
                }}
              >
                <p className="px-1 pb-2 text-[11px] font-medium text-white/55">Add Widgets</p>
                <div className="grid grid-cols-2 gap-2">
                  {WIDGET_OPTIONS.map((widget) => {
                    const isActive = activeWidgets.includes(widget.type);
                    return (
                      <button
                        key={widget.type}
                        type="button"
                        aria-pressed={isActive}
                        onClick={() => onToggleWidget?.(widget.type)}
                        className="group min-w-0 rounded-md p-1 text-left text-white/80 transition-colors hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1687ff]"
                      >
                        <span
                          className={`relative block aspect-[2/1] overflow-hidden rounded-[6px] border ${
                            isActive
                              ? "border-[#62aaff]"
                              : "border-white/15 group-hover:border-white/40"
                          }`}
                        >
                          <WidgetPreview type={widget.type} />
                          <span
                            className={`absolute right-1 top-1 flex h-[18px] w-[18px] items-center justify-center rounded-full text-[12px] leading-none text-white shadow ${
                              isActive
                                ? "bg-[#1687ff]"
                                : "bg-black/45 opacity-0 transition-opacity group-hover:opacity-100"
                            }`}
                          >
                            {isActive ? "✓" : "+"}
                          </span>
                        </span>
                        <span className="mt-1 block truncate px-0.5 text-[11px] font-medium">
                          {widget.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          <div className="my-1 h-[0.5px] bg-white/12 mx-1" />

          {/* Browse Projects */}
          <button
            onClick={() => {
              onOpenProjects();
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Browse Projects</span>
          </button>

          {/* Choose a Project (Submenu) */}
          <div
            className="relative"
            onMouseEnter={() => setActiveSubmenu("sortBy")}
            onMouseLeave={() => setActiveSubmenu(null)}
          >
            {activeSubmenu === "sortBy" && (
              <span
                aria-hidden="true"
                className={`pointer-events-auto absolute top-0 z-[99999] h-full w-1 ${
                  openSubmenuLeft ? "right-full" : "left-full"
                }`}
              />
            )}
            <button
              className={`group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors cursor-default ${
                activeSubmenu === "sortBy"
                  ? "bg-gradient-to-b from-[#1687ff] to-[#0071e3] text-white"
                  : "hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white"
              }`}
            >
              <span>Choose a Project</span>
              <svg
                className="h-3 w-3 text-white/50 group-hover:text-white"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
              >
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </button>

            {activeSubmenu === "sortBy" && (
              <div
                className={`absolute top-0 z-[100000] w-[180px] rounded-[10px] p-1 font-sans text-[13px] text-[#f5f5f7] shadow-[0_18px_40px_rgba(0,0,0,0.55),0_0_0_1px_rgba(255,255,255,0.12)_inset] animate-in fade-in zoom-in-95 duration-100 ${
                  openSubmenuLeft ? "right-full -translate-x-1" : "left-full translate-x-1"
                }`}
                style={{
                  background:
                    "linear-gradient(135deg, rgba(44, 44, 48, 0.66), rgba(26, 26, 30, 0.54) 45%, rgba(38, 38, 44, 0.62))",
                  backdropFilter: "blur(36px) saturate(190%)",
                  WebkitBackdropFilter: "blur(36px) saturate(190%)",
                  border: "1px solid rgba(255, 255, 255, 0.2)",
                  boxShadow:
                    "inset 0 1px 0 rgba(255, 255, 255, 0.3), inset 0 -1px 0 rgba(255, 255, 255, 0.07), 0 18px 48px rgba(0, 0, 0, 0.5), 0 4px 14px rgba(0, 0, 0, 0.28)",
                }}
              >
                {projects.map((project) => (
                  <button
                    key={project.id}
                    onClick={() => {
                      onOpenProject(project);
                      onClose();
                    }}
                    className="flex h-[26px] w-full items-center rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
                  >
                    <span className="truncate">{project.name}</span>
                  </button>
                ))}
                {projects.length === 0 && (
                  <span className="px-2.5 py-1.5 text-xs text-white/50">No projects available</span>
                )}
              </div>
            )}
          </div>

          {/* Reset Folder Positions */}
          <button
            onClick={() => {
              onCleanUp();
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Reset Folder Positions</span>
          </button>

          {/* Quick Open (Submenu) */}
          <div
            className="relative"
            onMouseEnter={() => setActiveSubmenu("cleanUpBy")}
            onMouseLeave={() => setActiveSubmenu(null)}
          >
            {activeSubmenu === "cleanUpBy" && (
              <span
                aria-hidden="true"
                className={`pointer-events-auto absolute top-0 z-[99999] h-full w-1 ${
                  openSubmenuLeft ? "right-full" : "left-full"
                }`}
              />
            )}
            <button
              className={`group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors cursor-default ${
                activeSubmenu === "cleanUpBy"
                  ? "bg-gradient-to-b from-[#1687ff] to-[#0071e3] text-white"
                  : "hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white"
              }`}
            >
              <span>Quick Open</span>
              <svg
                className="h-3 w-3 text-white/50 group-hover:text-white"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
              >
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </button>

            {activeSubmenu === "cleanUpBy" && (
              <div
                className={`absolute top-0 z-[100000] w-[180px] rounded-[10px] p-1 font-sans text-[13px] text-[#f5f5f7] shadow-[0_18px_40px_rgba(0,0,0,0.55),0_0_0_1px_rgba(255,255,255,0.12)_inset] animate-in fade-in zoom-in-95 duration-100 ${
                  openSubmenuLeft ? "right-full -translate-x-1" : "left-full translate-x-1"
                }`}
                style={{
                  background:
                    "linear-gradient(135deg, rgba(44, 44, 48, 0.66), rgba(26, 26, 30, 0.54) 45%, rgba(38, 38, 44, 0.62))",
                  backdropFilter: "blur(36px) saturate(190%)",
                  WebkitBackdropFilter: "blur(36px) saturate(190%)",
                  border: "1px solid rgba(255, 255, 255, 0.2)",
                  boxShadow:
                    "inset 0 1px 0 rgba(255, 255, 255, 0.3), inset 0 -1px 0 rgba(255, 255, 255, 0.07), 0 18px 48px rgba(0, 0, 0, 0.5), 0 4px 14px rgba(0, 0, 0, 0.28)",
                }}
              >
                {[
                  { label: "Projects", action: onOpenProjects },
                  { label: "Contact", action: () => onOpenApp("contact") },
                  { label: "Resume", action: () => onOpenApp("resume") },
                ].map(({ label, action }) => (
                  <button
                    key={label}
                    onClick={() => {
                      action();
                      onClose();
                    }}
                    className="flex h-[26px] w-full items-center rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
                  >
                    {label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="my-1 h-[0.5px] bg-white/12 mx-1" />

          {/* Open in Terminal */}
          <button
            onClick={() => {
              onOpenTerminal();
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Open in Terminal</span>
            <span className="text-[12px] text-white/40 tracking-wider group-hover:text-white">
              ⌃⌥T
            </span>
          </button>

          {/* Open Settings */}
          <button
            onClick={() => {
              onOpenSettings();
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Open Settings...</span>
            <span className="text-[12px] text-white/40 tracking-wider group-hover:text-white">
              ⌘J
            </span>
          </button>
        </div>
      )}

      {/* ─── FOLDER CONTEXT MENU ─── */}
      {menu.type === "folder" && (
        <div className="flex flex-col">
          {/* Rename */}
          <button
            onClick={() => {
              if (onRenameFolder) {
                onRenameFolder(menu.target);
              }
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Rename</span>
          </button>

          <button
            onClick={() => {
              onOpenFolder(menu.target);
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Open in Finder</span>
          </button>

          <div className="my-1 h-[0.5px] bg-white/12 mx-1" />

          {/* Get Info */}
          <button
            onClick={() => {
              onGetInfo(menu.target);
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Get Info</span>
            <span className="text-[12px] text-white/40 tracking-wider group-hover:text-white">
              ⌘I
            </span>
          </button>

          {/* Copy Name */}
          <button
            onClick={() => handleCopy(menu.target?.name || "Folder")}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>{copied ? "Copied!" : "Copy"}</span>
            <span className="text-[12px] text-white/40 tracking-wider group-hover:text-white">
              ⌘C
            </span>
          </button>

          <div className="my-1 h-[0.5px] bg-white/12 mx-1" />

          {/* Move to Trash */}
          <button
            onClick={() => {
              if (onDeleteFolder) {
                onDeleteFolder(menu.target);
              } else if (onDeleteCustomFolder) {
                onDeleteCustomFolder(menu.target?.id);
              }
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Move to Trash</span>
            <span className="text-[12px] text-white/40 tracking-wider group-hover:text-white">
              ⌘⌫
            </span>
          </button>
        </div>
      )}

      {/* ─── DESKTOP SHORTCUT CONTEXT MENU ─── */}
      {menu.type === "shortcut" && (
        <div className="flex flex-col">
          {/* Open App */}
          <button
            onClick={() => {
              onOpenShortcut(menu.target?.appId);
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Open {menu.target?.name || "App"}</span>
            <span className="text-[12px] text-white/40 tracking-wider group-hover:text-white">
              ⌘O
            </span>
          </button>

          <div className="my-1 h-[0.5px] bg-white/12 mx-1" />

          {/* Get Info */}
          <button
            onClick={() => {
              onGetInfo(menu.target);
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Get Info</span>
            <span className="text-[12px] text-white/40 tracking-wider group-hover:text-white">
              ⌘I
            </span>
          </button>

          <div className="my-1 h-[0.5px] bg-white/12 mx-1" />

          {/* Delete Shortcut */}
          <button
            onClick={() => {
              onDeleteShortcut(menu.target?.id);
              onClose();
            }}
            className="group flex h-[26px] w-full items-center justify-between rounded-[5px] px-2.5 text-left text-white/90 transition-colors hover:bg-gradient-to-b hover:from-[#1687ff] hover:to-[#0071e3] hover:text-white cursor-default"
          >
            <span>Delete Shortcut</span>
            <span className="text-[12px] text-white/40 tracking-wider group-hover:text-white">
              ⌘⌫
            </span>
          </button>
        </div>
      )}
    </div>,
    document.body,
  );
};

export default DesktopContextMenu;
